# Script de Automacao para o GitHub

$repo_token = "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"
$repo_url = "https://$($repo_token)@github.com/academiadeinformacaocientifica-gif/nos-na-diaspora.git"

Write-Host "--- Iniciando o upload ---"

# 1. Verifica Git
if (!(Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Error "Git nao encontrado no PATH."
    exit
}

# 2. Inicializa se necessario
if (!(Test-Path .git)) {
    git init
    Write-Host "Repositorio inicializado."
}

# 3. Configura Remote
git remote remove origin 2>$null
git remote add origin $repo_url
Write-Host "Remote configurado."

# 4. Commit
git add .
git commit -m "Updates: Slider, Comentarios e Categorias"
Write-Host "Commit concluido."

# 5. Push
Write-Host "Enviando arquivos..."
git push -u origin main -f

if ($LASTEXITCODE -eq 0) {
    Write-Host "SUCESSO: O projeto ja esta no GitHub."
}
else {
    Write-Host "ERRO: Ocorreu um problema no push."
}

Write-Host "--- Concluido ---"
Read-Host "Pressione Enter para fechar"
